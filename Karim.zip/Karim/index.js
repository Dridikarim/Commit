const serie = [2, 3, 4, 5, 6, 7, 8, 9, 10, 'Valet', 'Dame', 'Roi', 'As']
const paquet = [...serie, ...serie, ...serie, ...serie]
// cartes du joueur 1
let cartesJ1 = []
// cartes du joueur 2
let cartesJ2 = []
//cartes
let cartes = [...paquet]
//scores
let score1 = 0
let score2 = 0
console.log('###########################################  Debut de la partie  ###########################################')

// mélanger cartes
cartes.sort(() => Math.random() - 0.5 )
// distribuer Cartes
cartes.forEach( (carte, index) => {
    if(index % 2) {
        cartesJ1.push(carte) 
    } else {
        cartesJ2.push(carte)
    }
})
// Le jeu continue tant que les deux joueurs ont encore des cartes
while(cartesJ1.length || cartesJ2.length){
    // carte du joueur 1 
    let carte1 = cartesJ1[cartesJ1.length-1]
    // carte du joueur 2 
    let carte2 = cartesJ2[cartesJ2.length-1]

    console.log('Joueur 1 :', carte1, 'Joueur 2', carte2)
    // incrémenter le score gagnant, ne rien faire en cas de match nul
    if(serie.indexOf(carte1)< serie.indexOf(carte2) ){
        score2++
    }
    if (serie.indexOf(carte2) < serie.indexOf(carte1)) {
        score1++
    }
    console.log('Score joueur 1 :', score1, 'Score joueur 2 :', score2 )
    // Les cartes sont retirées du jeu
    cartesJ1.splice(cartesJ1.length-1, 1)
    cartesJ2.splice(cartesJ2.length-1, 1)
    console.log('------------------------------------------- Fin du Tour -------------------------------------------')
}
// Jeu terminé, affichage des résultats
console.log(`La partie se termine avec Joueur1 : ${score1} points et Joueur2 : ${score2} points `)
console.log(`Le gagnant est ********************************* ${score1 < score2 ? 'Joueur 2' : 'Joueur 1'}*********************************`)
console.log('###########################################  Fin de la partie  ###########################################')
